import { GPoint } from './types';
export declare function isMoveCmd(cmd: string): boolean;
export declare function GPointFromCmd(cmd: string, prev: GPoint): GPoint;
